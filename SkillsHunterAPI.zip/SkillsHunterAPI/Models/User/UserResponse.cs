﻿using System;

namespace SkillsHunterAPI.Models.User
{
    //This class will contain all the data that will be sent when a project is requested
    public class UserResponse
    {
        public UserResponse()
        {
        }
    }
}
