using System;

namespace SkillsHunterAPI.Models.Skill
{
    public class AddCategoryResponse
    {
        public bool Success  { get; set; }
        public Category Added  { get; set; }
    }
}
