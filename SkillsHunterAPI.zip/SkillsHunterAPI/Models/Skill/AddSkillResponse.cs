using System;

namespace SkillsHunterAPI.Models.Skill
{
    public class AddSkillResponse
    {
        public bool Success { get; set; }
        public Skill Added { get; set; }
    }
}
