using System;

namespace SkillsHunterAPI.Models.Skill
{
    public class RemoveSkillRequest
    {
        public Guid SkillId { get; set; }
    }
}
