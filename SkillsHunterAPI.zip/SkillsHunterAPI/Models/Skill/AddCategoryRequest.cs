using System;

namespace SkillsHunterAPI.Models.Skill
{
    public class AddCategoryRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
