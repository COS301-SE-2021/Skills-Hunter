using System;

namespace SkillsHunterAPI.Models.Project
{
    public class RemoveProjectRequest
    {
        public Guid ProjectId { get; set; }
    }
}
