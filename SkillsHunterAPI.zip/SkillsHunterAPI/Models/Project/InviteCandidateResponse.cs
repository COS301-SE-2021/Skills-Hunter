using System;

namespace SkillsHunterAPI.Models.Project
{
    public class InviteCandidateResponse{
        public bool Success { get; set; }
    }
}