﻿using System;
namespace SkillsHunterAPI.Models.Project
{
    public class Application
    {
        public Guid ApplicationId { get; set; }
        public Guid ApplicantId { get; set; }
        public Guid ProjectId { get; set; }
    }
}
