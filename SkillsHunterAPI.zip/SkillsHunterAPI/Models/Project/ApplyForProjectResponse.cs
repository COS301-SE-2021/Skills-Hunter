using System;

namespace SkillsHunterAPI.Models.Project
{
    public class ApplyForProjectResponse
    {
        public bool Success { get; set; }
    }
}